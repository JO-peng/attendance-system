﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Text;
using DotNetCasClient;

namespace MvcDemo.Controllers
{
    public class DefaultController : Controller
    {
        //
        // GET: /Default/

        public ActionResult Index()
        {

            HttpCookie ticketCookie = Request.Cookies[FormsAuthentication.FormsCookieName];
            if (ticketCookie != null)
            {
                ViewData["CookieDomain"] = ticketCookie.Domain;
                ViewData["CookieExpires"] = ticketCookie.Expires.ToString();
                ViewData["CookieName"] = ticketCookie.Name;
                ViewData["CookiePath"] = ticketCookie.Path;
                ViewData["CookieSecure"] = ticketCookie.Secure.ToString();

                if (!string.IsNullOrEmpty(ticketCookie.Value))
                {
                    int i = 0;
                    StringBuilder cookieValueBuilder = new StringBuilder();
                    while (i < ticketCookie.Value.Length)
                    {
                        string line = ticketCookie.Value.Substring(i, Math.Min(ticketCookie.Value.Length - i, 50));
                        cookieValueBuilder.Append(line + "<br />");
                        i += line.Length;
                    }

                    ViewData["CookieValue"]
                   = cookieValueBuilder.ToString();
                }

                if (!string.IsNullOrEmpty(ticketCookie.Value))
                {
                    FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(ticketCookie.Value);
                    if (ticket != null)
                    {
                        ViewData["TicketCookiePath"]
                        = ticket.CookiePath;
                        ViewData["TicketExpiration"]
                       = ticket.Expiration.ToString();
                        ViewData["TicketExpired"]
                       = ticket.Expired.ToString();
                        ViewData["TicketIsPersistent"]
                        = ticket.IsPersistent.ToString();
                        ViewData["TicketIssueDate"]
                        = ticket.IssueDate.ToString();
                        ViewData["TicketName"]
                        = ticket.Name;
                        ViewData["TicketUserData"]
                        = ticket.UserData;
                        ViewData["TicketVersion"]
                        = ticket.Version.ToString();
                    }

                    if (CasAuthentication.ServiceTicketManager != null)
                    {
                        CasAuthenticationTicket casTicket = CasAuthentication.ServiceTicketManager.GetTicket(ticket.UserData);
                        if (casTicket != null)
                        {
                            ViewData["CasNetId"]
                            = casTicket.NetId;
                            ViewData["CasServiceTicket"]
                            = casTicket.ServiceTicket;
                            ViewData["CasOriginatingServiceName"]
                           = casTicket.OriginatingServiceName;
                            ViewData["CasClientHostAddress"]
                           = casTicket.ClientHostAddress;
                            ViewData["CasValidFromDate"]
                           = casTicket.ValidFromDate.ToString();
                            ViewData["CasValidUntilDate"]
                            = casTicket.ValidUntilDate.ToString();
                            ViewData["ProxyGrantingTicket"]
                           = casTicket.ProxyGrantingTicket;
                            ViewData["ProxyGrantingTicketIou"]
                           = casTicket.ProxyGrantingTicketIou;

                            StringBuilder proxiesBuilder = new StringBuilder();
                            foreach (string proxy in casTicket.Proxies)
                            {
                                proxiesBuilder.AppendLine(proxy + "<br />");
                            }
                            ViewData["Proxies"]
                            = proxiesBuilder.ToString();

                            ViewData["AssertionPrincipalName"]
                           = casTicket.Assertion.PrincipalName;
                            ViewData["AssertionValidFromDate"]
                           = casTicket.Assertion.ValidFromDate.ToString();
                            ViewData["AssertionValidUntilDate"]
                            = casTicket.Assertion.ValidUntilDate.ToString();



                            ViewData["AssertionAttributes"] = casTicket.Assertion.Attributes;


                            //AssertionAttributesTable.Rows.Clear();
                            //string newLine = "<br />";
                            //StringBuilder assertionValuesBuilder = new StringBuilder();
                            //foreach (KeyValuePair<string, IList<string>> item in casTicket.Assertion.Attributes)
                            //{
                            //    TableRow assertionRow = new TableRow();

                            //    TableCell assertionKeyCell = new TableCell();
                            //    assertionKeyCell.VerticalAlign = VerticalAlign.Top;
                            //    assertionKeyCell.Text = item.Key;

                            //    TableCell assertionValuesCell = new TableCell();
                            //    assertionValuesCell.VerticalAlign = VerticalAlign.Top;

                            //    foreach (string value in item.Value)
                            //    {
                            //        assertionValuesBuilder.Append(value + newLine);
                            //    }

                            //    if (assertionValuesBuilder.Length > newLine.Length)
                            //    {
                            //        assertionValuesBuilder.Length -= newLine.Length;
                            //    }

                            //    assertionValuesCell.Text = assertionValuesBuilder.ToString();

                            //    assertionRow.Cells.Add(assertionKeyCell);
                            //    assertionRow.Cells.Add(assertionValuesCell);

                            //    AssertionAttributesTable.Rows.Add(assertionRow);
                            //    assertionValuesBuilder.Length = 0;
                            //}
                        }
                    }
                }
            }

            return View();
        }

    }
}

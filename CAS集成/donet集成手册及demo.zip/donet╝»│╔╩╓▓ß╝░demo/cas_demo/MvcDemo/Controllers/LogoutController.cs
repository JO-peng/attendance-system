﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DotNetCasClient;

namespace MvcDemo.Controllers
{
    public class LogoutController : Controller
    {
        //
        // GET: /Logout/

        public ActionResult Index()
        {
            const string serverurl = "http://authserver.wisedu.com/authserver/";

            if (CasAuthentication.ServiceTicketManager != null)
            {
                CasAuthentication.ClearAuthCookie();
                Session.Clear();
                /**Response.Redirect("~/Default.aspx");*/
                //CasAuthentication.SingleSignOut();
                //ClearAuthCookie();
                string singleSignOutRedirectUrl = string.Format("{0}/logout?service=/default.aspx", serverurl);

                // Leave endResponse as true.  This will throw a handled ThreadAbortException
                // but it is necessary to support SingleSignOut in ASP.NET MVC applications.
                Response.Redirect(singleSignOutRedirectUrl, true);
            }
            return View();
        }

    }
}

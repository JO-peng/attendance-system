﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetCasClient;
using DotNetCasClient.Utils;

public partial class Logout : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {
       const string serverurl = "http://authserver.wisedu.com/authserver/";

        if (CasAuthentication.ServiceTicketManager != null)
        {
            CasAuthentication.ClearAuthCookie();
           Session.Clear();        
            /**Response.Redirect("~/Default.aspx");*/
            //CasAuthentication.SingleSignOut();
			  //ClearAuthCookie();
           string singleSignOutRedirectUrl = string.Format("{0}/logout?service=/default.aspx", serverurl);
                
                // Leave endResponse as true.  This will throw a handled ThreadAbortException
                // but it is necessary to support SingleSignOut in ASP.NET MVC applications.
                Response.Redirect(singleSignOutRedirectUrl, true);
        }
       
    }
}
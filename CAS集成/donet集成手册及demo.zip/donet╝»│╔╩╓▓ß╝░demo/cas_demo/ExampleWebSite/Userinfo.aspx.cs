﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetCasClient;
using System.Text;
using DotNetCasClient.Security;
using DotNetCasClient.Utils;
using System.Linq;

public partial class Userinfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        string userName = User.Identity.Name ;
       
        CasPrincipal p =Page.User as CasPrincipal ;

        ///Response.Write("p " + p.Assertion.Attributes.Count);

        //HttpCookie ticketCookie = Request.Cookies[FormsAuthentication.FormsCookieName];       
        //FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(ticketCookie.Value);
        //CasAuthenticationTicket casTicket = CasAuthentication.ServiceTicketManager.GetTicket(ticket.UserData);

        
         //获得所有传递过来的用户属性
        Dictionary<string, string> userAttrs = new Dictionary<string, string>();
        var cnValue=UserAttrHelper.GetUserAttrValueByParamName("cn");
        var aliasValue=UserAttrHelper.GetUserAttrValueByParamName("alias");
        userAttrs.Add("cn",string.Join(",",cnValue));
        userAttrs.Add("alias", string.Join(",", aliasValue));
        //foreach (KeyValuePair<string, IList<string>> attribute in casTicket.Assertion.Attributes)
        //    {
        //        string key = attribute.Key;
        //        Response.Write("key:" + key + "::::" + attribute.Value);

        //        StringBuilder builder = new StringBuilder();
        //        foreach (string valuePart in attribute.Value)
        //        {
        //            builder.AppendLine("        " + valuePart);
        //        }
        //        userAttrs.Add(key, builder.ToString());

        //    }   

          

        user.Text = userName.ToString();
        attr.DataSource = userAttrs;
        attr.DataBind();

    }




    public static FormsAuthenticationTicket GetFormsAuthenticationTicket()
    {
        //Initialize();
        HttpContext context = HttpContext.Current;
        HttpCookie cookie = context.Request.Cookies[FormsAuthentication.FormsCookieName];

        if (cookie == null)
        {
            return null;
        }

        if (cookie.Expires != DateTime.MinValue && cookie.Expires < DateTime.Now)
        {
           // ClearAuthCookie();
            return null;
        }

        if (String.IsNullOrEmpty(cookie.Value))
        {
            //ClearAuthCookie();
            return null;
        }

        FormsAuthenticationTicket formsAuthTicket;
        try
        {
            formsAuthTicket = FormsAuthentication.Decrypt(cookie.Value);
        }
        catch
        {
            //ClearAuthCookie();
            return null;
        }

        if (formsAuthTicket == null)
        {
            //ClearAuthCookie();
            return null;
        }

        if (formsAuthTicket.Expired)
        {
            //ClearAuthCookie();
            return null;
        }

        if (String.IsNullOrEmpty(formsAuthTicket.UserData))
        {
            //ClearAuthCookie();
            return null;
        }

        return formsAuthTicket;
    }
}
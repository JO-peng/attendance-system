﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotNetCasClient.Configuration;
using System.Text.RegularExpressions;

namespace DotNetCasClient
{
    public class Urls
    {
        /// <summary>
        /// 验证url是否符合规则
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public static bool FiterUrls(System.Web.HttpContext context)
        {
            var UrlMappingTable = ReWritingConfigurationSetHandler.GetUrlMappingTable;
            string OriginalUrl = context.Request.Path;
            string pattern = null;
            foreach (Object key in UrlMappingTable.Keys)
            {
                pattern = UrlMappingTable[key].ToString();
                Match match = Regex.Match(OriginalUrl, pattern, RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);
                String desitional = string.Empty;

                if (match.Success)
                {
                    return true;
                    //desitional = UrlMappingTable[key].ToString();
                    //for (int i = 1; i < match.Groups.Count; i++)
                    //{
                    //    desitional = desitional.Replace("$" + i, match.Groups[i].ToString());
                    //}
                    //context.RewritePath(desitional);
                }
            }
            return false;
        }
    }
}

﻿/*
 * Licensed to Jasig under one or more contributor license
 * agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership.
 * Jasig licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a
 * copy of the License at:
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

using System;
using DotNetCasClient.Security;
using System.Web;
using System.Web.Security;
using System.Collections.Generic;
using System.Web.UI;
using System.Text;
using System.Collections;
using System.Linq;

namespace DotNetCasClient.Utils
{
    /// <summary>
    /// Utility methods for the Jasig CAS Client.
    /// </summary>
    /// <author>Marvin S. Addison</author>
    public static class CommonUtils
    {
        /// <summary>
        /// Checks whether the object is null.
        /// </summary>
        /// <param name="entity">the object to check</param>
        /// <param name="message">the message to display if the object is null.</param>
        /// <exception cref="ArgumentNullException">
        /// Thrown when the object is <code>null</code>.  Includes the provided
        /// message.
        /// </exception>
        public static void AssertNotNull(object entity, string message)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(message);
            }
        }

        /// <summary>
        /// Checks whether the string is null or empty.
        /// </summary>
        /// <param name="entity">the string to check</param>
        /// <param name="message">the message to display if the string is null or empty.</param>
        /// <exception cref="ArgumentNullException">
        /// Thrown when the object is <code>null</code>.  Includes the provided
        /// message.
        /// </exception>
        /// <exception cref="ArgumentException">
        /// Thrown when the object is an empty string.  Includes the provided
        /// message.
        /// </exception>
        public static void AssertNotNullOrEmpty(string entity, string message)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(message);
            }
            else if (string.IsNullOrEmpty(entity))
            {
                throw new ArgumentException(message);
            }
        }

       
    }

    /// <summary>
    /// 用户基本属性帮助类
    /// </summary>
    public class UserAttrHelper : System.Web.UI.Page
    {
        /// <summary>
        /// 获取key相关的属性值,例如：cn
        /// </summary>
        /// <param name="key"></param>
        public static string[] GetUserAttrValueByParamName(string keyStr)
        {
           // CasPrincipal p = Page.User as CasPrincipal;
            HttpCookie ticketCookie = System.Web.HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];
            FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(ticketCookie.Value);
            CasAuthenticationTicket casTicket = CasAuthentication.ServiceTicketManager.GetTicket(ticket.UserData);

            //获得所有传递过来的用户属性
            List<UserAttr> userAttrs = new List<UserAttr>();

            foreach (KeyValuePair<string, IList<string>> attribute in casTicket.Assertion.Attributes)
            {
                string key = attribute.Key;
                List<string> arr = new List<string> { };
                //StringBuilder builder = new StringBuilder();

                foreach (string valuePart in attribute.Value)
                {
                    arr.Add(valuePart);
                    //builder.AppendLine("        " + valuePart);
                }
                userAttrs.Add(new UserAttr { UserKey = key, UserAttrValue = arr.ToArray() });
            }
            var str = userAttrs.Where(v => v.UserKey == keyStr);
            if (str.Any())
            {
                return str.FirstOrDefault().UserAttrValue;
            }
            return new[] { "你查询的key不存在！" };
        }
    }
    /// <summary>
    /// 用户的信息
    /// </summary>
    public class UserAttr {
        public string UserKey { get; set; }
        public string[] UserAttrValue { get; set; }
    }
}

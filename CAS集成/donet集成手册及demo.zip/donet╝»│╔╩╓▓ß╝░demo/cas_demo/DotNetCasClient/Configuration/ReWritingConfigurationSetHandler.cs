﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Collections;
using System.Xml;

namespace DotNetCasClient.Configuration
{
    public class ReWritingConfigurationSetHandler :IConfigurationSectionHandler
    {
        static Hashtable urlMappingTable = new Hashtable();  
        public const string urls="FilterUrls";


        object IConfigurationSectionHandler.Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            XmlNode node = section.SelectSingleNode("Rules");
            foreach (XmlNode childNode in node.ChildNodes)
            {
                string ServletName, UrlMapping;
                ServletName = childNode.SelectSingleNode("ServletName").InnerText;
                UrlMapping = childNode.SelectSingleNode("Url-Mapping").InnerText;
                urlMappingTable.Add(ServletName, UrlMapping);
            }
            return urlMappingTable;

        }
        public static Hashtable GetUrlMappingTable
        {
            get
            {
                return (Hashtable)System.Configuration.ConfigurationSettings.GetConfig("FilterUrls");
            }
            set
            {
                urlMappingTable = value;
            }
        }  

       
    }
}
